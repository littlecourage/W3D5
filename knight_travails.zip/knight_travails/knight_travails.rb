require_relative "00_tree_node.rb"
class KnightPathFinder

    
    def initialize(start_pos_arr)
        @root_node = PolyTreeNode.new(start_pos_arr)
    end
    
    # @root_node = PolyTreeNode.new(@starting_pos)
    
end